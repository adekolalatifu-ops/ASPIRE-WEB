const money = n => new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(n);
const fallbackProducts = [
  {id:"asp-001",name:"Essential Logo Tee",description:"Heavyweight everyday fit",price:20000,image:"",category:"T-shirts"},
  {id:"asp-002",name:"Core Street Tee",description:"Relaxed fit / minimal branding",price:20000,image:"",category:"T-shirts"},
  {id:"asp-003",name:"Signature Polo",description:"Classic cut / embroidered detail",price:25000,image:"",category:"Polos"}
];
let products = fallbackProducts;
let cart = JSON.parse(localStorage.getItem("aspire-cart") || "[]");
let lastOrder = null;

const grid = document.querySelector("#product-grid");
const cartCount = document.querySelector("#cart-count");
const drawer = document.querySelector("#cart-drawer");
const backdrop = document.querySelector("#drawer-backdrop");
const checkoutDialog = document.querySelector("#checkout-dialog");
const successDialog = document.querySelector("#success-dialog");

async function loadProducts(){
  try {
    const res = await fetch("/api/products");
    if(res.ok){ const data = await res.json(); if(Array.isArray(data.products) && data.products.length) products = data.products; }
  } catch {}
  renderProducts(); renderCart();
}
function renderProducts(){
  grid.innerHTML = products.map(p => `
    <article class="product-card">
      <div class="product-image">${p.image ? `<img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}">` : `<span class="product-placeholder">ASPIRE®</span>`}</div>
      <div class="product-info"><div><h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.description || "")}</p></div><span class="product-price">${money(Number(p.price))}</span></div>
      <button class="add-button" data-add="${escapeHtml(p.id)}">ADD TO BAG +</button>
    </article>`).join("");
  grid.querySelectorAll("[data-add]").forEach(b=>b.addEventListener("click",()=>addToCart(b.dataset.add)));
}
function escapeHtml(s){return String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function saveCart(){localStorage.setItem("aspire-cart",JSON.stringify(cart));renderCart();}
function addToCart(id){const p=products.find(x=>x.id===id);if(!p)return;const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id:p.id,name:p.name,price:Number(p.price),qty:1});saveCart();openCart();}
function renderCart(){
  cartCount.textContent=cart.reduce((n,x)=>n+x.qty,0);
  const target=document.querySelector("#cart-items");
  if(!cart.length){target.innerHTML='<p class="muted">Your bag is empty.</p>';}
  else target.innerHTML=cart.map(x=>`<div class="cart-row"><div><strong>${escapeHtml(x.name)}</strong><p class="tiny muted">${money(x.price)} × ${x.qty}</p></div><div><strong>${money(x.price*x.qty)}</strong><br><button data-remove="${escapeHtml(x.id)}">REMOVE</button></div></div>`).join("");
  target.querySelectorAll("[data-remove]").forEach(b=>b.addEventListener("click",()=>{cart=cart.filter(x=>x.id!==b.dataset.remove);saveCart();}));
  document.querySelector("#cart-total").textContent=money(cart.reduce((n,x)=>n+x.price*x.qty,0));
}
function openCart(){drawer.classList.add("open");backdrop.classList.add("open");drawer.setAttribute("aria-hidden","false");}
function closeCart(){drawer.classList.remove("open");backdrop.classList.remove("open");drawer.setAttribute("aria-hidden","true");}
document.querySelector("#open-cart").addEventListener("click",openCart);
document.querySelector("#close-cart").addEventListener("click",closeCart);
backdrop.addEventListener("click",closeCart);
document.querySelector("#checkout-button").addEventListener("click",()=>{
  if(!cart.length){alert("Your bag is empty.");return;}
  closeCart();checkoutDialog.showModal();
});
document.querySelector("#close-checkout").addEventListener("click",()=>checkoutDialog.close());
document.querySelector("#close-success").addEventListener("click",()=>successDialog.close());
document.querySelector("#done-button").addEventListener("click",()=>successDialog.close());
document.querySelector("#year").textContent=new Date().getFullYear();

document.querySelector("#checkout-form").addEventListener("submit",async e=>{
  e.preventDefault();
  const form=e.currentTarget;
  const submit=form.querySelector('[type="submit"]');
  submit.disabled=true;submit.textContent="PLACING ORDER…";
  const fd=new FormData(form);
  const payload={customer:{name:fd.get("name"),phone:fd.get("phone"),address:fd.get("address"),note:fd.get("note")},items:cart.map(x=>({id:x.id,quantity:x.qty})),paymentMethod:"bank-transfer"};
  try{
    const res=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
    if(!res.ok)throw new Error("Could not submit order");
    const data=await res.json();lastOrder=data.order;
    document.querySelector("#success-text").textContent=`Your order reference is ${data.order.reference}. Keep it for your records.`;
    document.querySelector("#bank-name").textContent=data.bank?.bankName||"Contact store owner";
    document.querySelector("#account-name").textContent=data.bank?.accountName||"Not configured";
    document.querySelector("#account-number").textContent=data.bank?.accountNumber||"Not configured";
  }catch(err){
    // Local preview mode: this is not a real submitted order.
    const ref="LOCAL-"+Date.now().toString().slice(-7);
    document.querySelector("#success-text").textContent=`Preview order reference: ${ref}. This preview has not been saved to a live store. Deploy the Cloudflare backend and D1 database to receive real orders.`;
    document.querySelector("#bank-name").textContent="Configure in Cloudflare";
    document.querySelector("#account-name").textContent="Configure in Cloudflare";
    document.querySelector("#account-number").textContent="Configure in Cloudflare";
  }
  cart=[];saveCart();form.reset();checkoutDialog.close();successDialog.showModal();
  submit.disabled=false;submit.textContent="PLACE ORDER";
});
loadProducts();
