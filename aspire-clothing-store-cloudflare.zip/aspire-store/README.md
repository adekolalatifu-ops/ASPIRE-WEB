# ASPIRE Clothing Store — Cloudflare Pages starter

This is a small, editable storefront for GitHub + Cloudflare Pages. It includes a product grid, shopping bag, checkout form, bank-transfer instructions, a D1-backed order API, and a password-protected order dashboard.

## 1. Put it on GitHub
1. Sign in at https://github.com.
2. Create a new repository named `aspire-clothing-store`.
3. Upload **all files and folders** from this project, keeping the folder structure.
4. Make sure `index.html` is in the repository root (not inside another nested folder).

## 2. Create the Cloudflare D1 database
1. Sign in at https://dash.cloudflare.com.
2. Open **Workers & Pages → D1 SQL Database** (the menu wording may vary).
3. Create a database named `aspire-store-db`.
4. Open its Console and paste the complete contents of `schema.sql`, then run it.

## 3. Connect the GitHub repository to Cloudflare Pages
1. Open **Workers & Pages → Create application → Pages → Connect to Git**.
2. Choose the `aspire-clothing-store` repository.
3. Framework preset: **None**.
4. Build command: leave blank.
5. Build output directory: `/` (if the dashboard rejects `/`, use `.`).
6. Deploy.

## 4. Bind the database
In your Pages project, open **Settings → Functions → D1 database bindings** (menu wording may vary).
- Variable name: `DB`
- Choose the database `aspire-store-db`
Save and redeploy.

## 5. Add private environment variables
In **Settings → Variables and Secrets**, add these as encrypted secrets where supported:
- `ADMIN_PASSWORD` — choose a strong, unique password and keep it private.
- `BANK_NAME` — your store's bank name.
- `BANK_ACCOUNT_NAME` — the account holder name.
- `BANK_ACCOUNT_NUMBER` — your store's account number.

Only the bank details are returned after an order is submitted. Never put the admin password in public HTML or JavaScript. For a real store, have a parent/guardian help manage the bank account and customer information.

## 6. Test it
- Open your Pages website URL.
- Add an item to the bag and submit a test order.
- Open `/admin.html`, enter your admin password and load orders.
- Mark the test order as paid/processing/shipped to check the status controls.
- Delete test orders from the D1 database console when finished.

## Editing products
Edit the `INSERT` rows in `schema.sql` before running it, or add/edit products using the D1 console. Product images should be public HTTPS image URLs. The product table is the source of truth for live products and prices.

## Important limitations
- This starter accepts bank-transfer orders but does **not** automatically verify bank payments. The store owner must check the payment through their bank before marking an order paid.
- It does not collect card details and does not integrate a payment gateway.
- Add spam protection, privacy/returns pages, delivery rules, and backups before opening the store to the public.
- The sample products and prices are placeholders. Replace them with your actual products and prices.
