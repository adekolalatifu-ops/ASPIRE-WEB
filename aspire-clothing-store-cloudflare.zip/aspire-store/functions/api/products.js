export async function onRequestGet({ env }) {
  try {
    const { results } = await env.DB.prepare(
      "SELECT id,name,description,price,image,category FROM products WHERE active=1 ORDER BY rowid DESC"
    ).all();
    return Response.json({ products: results });
  } catch {
    return Response.json({ products: [] });
  }
}
