function json(data,status=200){return Response.json(data,{status,headers:{"Cache-Control":"no-store"}});}
function authorized(request,env){
  const expected=env.ADMIN_PASSWORD;
  const supplied=(request.headers.get("Authorization")||"").replace(/^Bearer\s+/i,"");
  return Boolean(expected&&supplied&&supplied===expected);
}
export async function onRequest({request,env}){
  if(!authorized(request,env))return json({error:"Unauthorized"},401);
  if(request.method==="GET"){
    const {results}=await env.DB.prepare("SELECT id,reference,customer_name,phone,address,items_summary,total,status,created_at FROM orders ORDER BY id DESC LIMIT 200").all();
    return json({orders:results});
  }
  if(request.method==="PATCH"){
    const body=await request.json();
    const allowed=["pending","paid","processing","shipped","cancelled"];
    if(!Number.isInteger(Number(body.id))||!allowed.includes(body.status))return json({error:"Invalid update"},400);
    await env.DB.prepare("UPDATE orders SET status=? WHERE id=?").bind(body.status,Number(body.id)).run();
    return json({ok:true});
  }
  return json({error:"Method not allowed"},405);
}
