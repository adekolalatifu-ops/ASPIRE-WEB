function json(data,status=200){return Response.json(data,{status,headers:{"Cache-Control":"no-store"}});}
function makeReference(){return "ASP-"+Date.now().toString(36).toUpperCase()+"-"+crypto.randomUUID().slice(0,4).toUpperCase();}
export async function onRequestPost({request,env}){
  try{
    const body=await request.json();
    const c=body.customer||{};
    const name=String(c.name||"").trim(),phone=String(c.phone||"").trim(),address=String(c.address||"").trim(),note=String(c.note||"").trim();
    if(!name||!phone||!address||!Array.isArray(body.items)||body.items.length<1||body.items.length>30)return json({error:"Please provide valid customer and order details."},400);
    if(name.length>100||phone.length>30||address.length>500||note.length>300)return json({error:"One or more fields are too long."},400);
    const ids=[...new Set(body.items.map(x=>String(x.id||"")))];
    if(ids.some(x=>!x||x.length>80))return json({error:"Invalid product."},400);
    const placeholders=ids.map(()=>"?").join(",");
    const {results}=await env.DB.prepare(`SELECT id,name,price,active FROM products WHERE id IN (${placeholders}) AND active=1`).bind(...ids).all();
    if(results.length!==ids.length)return json({error:"A product is no longer available. Refresh and try again."},400);
    const productMap=new Map(results.map(p=>[p.id,p]));
    const items=[];
    for(const line of body.items){
      const p=productMap.get(String(line.id));const qty=Number(line.quantity);
      if(!Number.isInteger(qty)||qty<1||qty>10)return json({error:"Invalid quantity."},400);
      items.push({id:p.id,name:p.name,price:p.price,quantity:qty});
    }
    const total=items.reduce((sum,x)=>sum+x.price*x.quantity,0);
    if(total>100000000)return json({error:"Order total is too large."},400);
    const reference=makeReference();
    const summary=items.map(x=>`${x.name} × ${x.quantity}`).join(", ");
    await env.DB.prepare(`INSERT INTO orders (reference,customer_name,phone,address,note,items_json,items_summary,total,status) VALUES (?,?,?,?,?,?,?,?, 'pending')`)
      .bind(reference,name,phone,address,note,JSON.stringify(items),summary,total).run();
    return json({order:{reference,total,status:"pending"},bank:{bankName:env.BANK_NAME||"",accountName:env.BANK_ACCOUNT_NAME||"",accountNumber:env.BANK_ACCOUNT_NUMBER||""}},201);
  }catch(e){return json({error:"Unable to save order. Check that the database is connected."},500);}
}
